# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'myplugin_dialog_base.ui'
#
# Created: Thu Oct 18 13:36:27 2018
#      by: PyQt4 UI code generator 4.10.2
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

class Ui_myPluginDialogBase(object):
    def setupUi(self, myPluginDialogBase):
        myPluginDialogBase.setObjectName(_fromUtf8("myPluginDialogBase"))
        myPluginDialogBase.resize(400, 300)
        self.button_box = QtGui.QDialogButtonBox(myPluginDialogBase)
        self.button_box.setGeometry(QtCore.QRect(30, 240, 341, 32))
        self.button_box.setOrientation(QtCore.Qt.Horizontal)
        self.button_box.setStandardButtons(QtGui.QDialogButtonBox.Cancel|QtGui.QDialogButtonBox.Ok)
        self.button_box.setObjectName(_fromUtf8("button_box"))

        self.retranslateUi(myPluginDialogBase)
        QtCore.QObject.connect(self.button_box, QtCore.SIGNAL(_fromUtf8("accepted()")), myPluginDialogBase.accept)
        QtCore.QObject.connect(self.button_box, QtCore.SIGNAL(_fromUtf8("rejected()")), myPluginDialogBase.reject)
        QtCore.QMetaObject.connectSlotsByName(myPluginDialogBase)

    def retranslateUi(self, myPluginDialogBase):
        myPluginDialogBase.setWindowTitle(_translate("myPluginDialogBase", "Mi enchufable", None))

